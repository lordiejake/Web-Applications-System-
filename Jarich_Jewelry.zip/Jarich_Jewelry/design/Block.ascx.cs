using System.Web.UI;

public partial class design_WebUserControlBlock : UserControl
{ }
